==================================================================
  ASCII Art OFX Plugin (Linux x86_64) - v1.2 Build 10
==================================================================

NO INSTALLATION / NO DEPENDENCIES REQUIRED!
The plugin is already fully pre-compiled inside "AsciiArt.ofx.bundle".

METHOD 1: DRAG & DROP (RECOMMENDED - ZERO INSTALL)
--------------------------------------------------
Simply copy or drag the "AsciiArt.ofx.bundle" folder to either:
  * System-wide:  /usr/OFX/Plugins/
  * OR User-only: ~/.ofx/Plugins/   (no root/sudo required!)

Restart DaVinci Resolve and you're done!

METHOD 2: ONE-CLICK SCRIPT (OPTIONAL)
-------------------------------------
1. Open terminal in this folder.
2. Run:
   chmod +x install.sh
   ./install.sh
3. Restart DaVinci Resolve!

HIGHLIGHTS IN BUILD 10:
* 100% Pre-compiled Standalone Bundle (no terminal or compiler needed)
* Direct Website Button: Click in inspector opens https://therealskb.carrd.co/
* Goliath Encrypted Font included (auto-loaded from bundle Resources/)
* Skip Black Areas & Cutoff threshold sliders
* Uniform Character Spacing slider (up to 200px)
* Cyber Lime / Acid Green (#C2FD04) color modes
* Custom Font file browser support (.ttf / .otf)
* Frame Hold (Update Every N Frames: 1-12)
* Multi-Core OpenMP acceleration (smooth 4K playback)

UNINSTALL:
   chmod +x uninstall.sh
   ./uninstall.sh
   (Or simply delete AsciiArt.ofx.bundle from /usr/OFX/Plugins/ or ~/.ofx/Plugins/)
==================================================================
