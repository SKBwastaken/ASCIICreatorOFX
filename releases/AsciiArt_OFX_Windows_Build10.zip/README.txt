==================================================================
  ASCII Art OFX Plugin (Windows x64) - v1.2 Build 10
==================================================================

INSTALLATION (1-CLICK):
1. Extract all contents from this ZIP folder.
2. Double-click "Install.bat" (Windows will ask for permission).
3. Start or restart DaVinci Resolve.
4. In the Edit or Color page:
   Go to Effects -> OpenFX -> Stylize -> "ASCII Art".
5. Drag onto your clip!

FEATURES:
- Goliath Encrypted Font included (auto-detected and selected by default).
- Skip Black Areas (default ON): completely skips dark & transparent areas to prevent faint/stray symbols on black backgrounds.
- Black & Alpha Cutoff Thresholds: fully adjustable sliders to define the exact shadow cutoff point.
- Single Character Spacing slider (2 to 200px+): guarantees perfectly square, uniform character spacing horizontally & vertically.
- Cyber Lime / Acid Green (#C2FD04) color modes for authentic cyber/terminal aesthetic.
- Direct Website Button: In-plugin button links directly to https://therealskb.carrd.co/
- Update Every N Frames (Frame Hold): 1 = every frame, 2 = half-rate, 3 = 1/3 rate (Matrix/Cyberpunk style, reduces flickering, cuts rendering load by 50-70%).
- High-Performance Multi-Core Hardware Acceleration (OpenMP) across all CPU cores.
- Ultra-fast integer fixed-point alpha blending with zero-allocation memory buffer.
- 100% Edge-to-Edge seamless ASCII grid without border gaps or truncations.
- 100% Standalone (includes bundled OpenMP runtime, zero external installs required).

UNINSTALL:
- Double-click "Uninstall.bat" to cleanly remove the plugin.
==================================================================
